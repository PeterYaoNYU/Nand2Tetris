for i in range(1,9):
    print(f"    RAM4k(in=in, load=load{i}, address=address[0..11], out=out{i});")
